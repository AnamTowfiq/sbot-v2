import pyautogui
import time

time.sleep(3)

spam_text = input("Your spam word:")

for _ in range(20):
    pyautogui.typewrite(spam_text)
    pyautogui.press('enter')
    time.sleep(0.15)